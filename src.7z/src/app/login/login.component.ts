import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { UserService } from '../user.service';
import { Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  falha_preenchimento: boolean = false;
  falha_login: boolean = false;
  opcao_login: boolean = false;
  opcao_cadastro: boolean = false;

  loginForm = this.formBuilder.group({
    login: new FormControl('', [
      Validators.required,
      Validators.minLength(4)]),
    senha: new FormControl('', [
      Validators.required,
      Validators.minLength(4)]),
  });
  constructor(private formBuilder: FormBuilder,
    private user: UserService,
    private router: Router) { }

  ngOnInit(): void {
  }

  onSubmit(): void {
    // Process checkout data here
    this.falha_preenchimento = false;
    if (this.loginForm.valid)
    {
      console.warn(this.loginForm.value)
      var login = this.loginForm.value['login'];
      var senha = this.loginForm.value['senha'];
      if (login == 'vterez' && senha == 'lola')
      {
        console.warn('Login realizado com sucesso', this.loginForm.value);
        this.falha_login = false;
        this.user.login = login;
        this.user.token = 'ashdfiashdf';
        this.user.nome = 'Vitor Rezende';
        this.router.navigate(['/user']);
      }
      else
      {
        this.falha_login = true;
        alert("Usuário e/ou senha inválidos");
      }
      
    }
    else
    {
      if (this.loginForm.get('login')?.errors?.minlength)
        {
          console.warn('falhou login');
          this.falha_login = true;}
      this.falha_preenchimento = true;
    }
    //this.loginForm.reset();
  }

}
