import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  items = this.cartService.getItems();
  shipping = this.cartService.shipping;
  total = 10;///this.items.reduce((a,b) => a+b.price,0)+this.shipping.price;
  constructor( private cartService: CartService) { }

  ngOnInit() {
  }

}