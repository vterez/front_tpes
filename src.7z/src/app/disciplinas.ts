export interface Avaliacao
{
  id: number;
  name: string;
  data: Date;
  conteudo: string[];
}

export interface Disciplina {
  id: number;
  name: string;
  avaliacoes: Avaliacao[]
}

export const disciplinas = [
  {
    id: 1,
    name: 'PDS1',
    avaliacoes: [
      {id: 1, name:"TP1", data:new Date(), conteudo:[]},
      {id: 4, name:"P1", data:new Date(), conteudo:["Matrizes"]}
    ]
  },
  {
    id: 2,
    name: 'PDS2',
    avaliacoes: [
      {id: 2, name:"TP2", data:new Date(), conteudo:[]}
    ]
  },
  {
    id: 3,
    name: 'ED',
    avaliacoes: [
      {id: 3, name:"TP3", data:new Date(), conteudo:[]}
    ]
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/