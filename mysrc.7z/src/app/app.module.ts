import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
//import { JwtHelperService } from '@auth0/angular-jwt';

import { AppComponent } from './app.component';
import { TopBarComponent } from './top-bar/top-bar.component';
import { DisciplinaListComponent } from './disciplina-list/disciplina-list.component';
import { DisciplinaDetailsComponent } from './disciplina-details/disciplina-details.component';
import { CartComponent } from './cart/cart.component';
import { ShippingComponent } from './shipping/shipping.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '', component: LoginComponent},
      { path: 'user', component: DisciplinaListComponent },
      { path: 'disciplinas/:disciplinaId', component: DisciplinaDetailsComponent },
      { path: 'cart', component: CartComponent },
      { path: 'shipping', component: ShippingComponent },
        ])
  ],
  declarations: [
    AppComponent,
    TopBarComponent,
    DisciplinaListComponent,
    DisciplinaDetailsComponent,
    CartComponent,
    ShippingComponent,
    LoginComponent
    ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/