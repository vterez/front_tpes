import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../user.service';
import { Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, AfterViewInit {

  falha_preenchimento: boolean = false;
  falha_login: boolean = false;
  opcao_login: boolean = false;
  opcao_cadastro: boolean = false;
  mensagem_erro: string = '';

  loginForm = this.formBuilder.group({
    login: ['', Validators.required],
    senha: ['', [Validators.required,Validators.minLength(8)]],
  });

  cadastroForm = this.formBuilder.group({
    nome: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    login: ['', Validators.required],
    senha: ['', [Validators.required,Validators.minLength(8)]],
  });

  constructor(private formBuilder: FormBuilder,
    private user: UserService,
    private router: Router) { }

  ngOnInit(): void {
  }

  ngAfterViewInit()
  {
    if (this.user.logado)
      this.router.navigate(['/user']);
  }

  onSubmit(): void {
    // Process checkout data here
    this.falha_preenchimento = false;
    this.mensagem_erro = '';
    if (this.opcao_login)
    {
      if (this.loginForm.valid)
      {
        var login = this.loginForm.value['login'];
        var senha = this.loginForm.value['senha'];
        //valida com o back
        if (login == 'vterez' && senha == '12345678')
        {
          this.falha_login = false;
          this.user.login = login;
          this.user.token = 'ashdfiashdf';
          this.user.nome = 'Vitor Rezende';
          this.user.logado = true;
          this.router.navigate(['/user']);
        }
        else
        {
          this.falha_login = true;
          alert("Usuário e/ou senha inválidos");
        }
      }
      else
      {
        this.falha_preenchimento = true;
        console.warn("Falhou");
        console.warn(this.loginForm.controls['login'].errors);
        console.warn(this.loginForm.controls['senha'].errors);
        if (this.loginForm.controls['login'].errors?.required)
          this.mensagem_erro = 'Preencha seu login\n';
        else if (this.loginForm.controls['senha'].errors?.required)
          this.mensagem_erro = 'Preencha sua senha\n';
        else if (this.loginForm.controls['senha'].errors?.minlength)
          this.mensagem_erro = 'Senha muito curta\n';
        console.warn(this.mensagem_erro);
        console.warn(this.falha_preenchimento);
      }
    }
    else
    {
      if (this.cadastroForm.valid)
      {
        //valida com o back
        if (true)
        {
          this.user.nome = 'Vitor Rezende';
          this.user.logado = true;
          this.user.token = 'oiasjfasuidf';
          this.router.navigate(['/user']);
        }
        else
        {
          this.falha_login = true;
          alert("Usuário e/ou senha inválidos");
        }
      }
      else
      {
        this.falha_preenchimento = true;
        console.warn("Falhou");
        console.warn(this.cadastroForm.controls['email'].errors);
        if (this.cadastroForm.controls['nome'].errors?.required)
          this.mensagem_erro = 'Preencha seu nome\n';
        else if (this.cadastroForm.controls['email'].errors?.email || 
                 this.cadastroForm.controls['email'].errors?.required)
          this.mensagem_erro = 'Insira um e-mail válido\n';
        else if (this.cadastroForm.controls['login'].errors?.required)
          this.mensagem_erro = 'Preencha seu login\n';
        else if (this.cadastroForm.controls['senha'].errors?.required)
          this.mensagem_erro = 'Preencha sua senha\n';
        else if (this.cadastroForm.controls['senha'].errors?.minlength)
          this.mensagem_erro = 'Senha deve ter no mínimo 8 caracteres\n';
        else if (this.cadastroForm.controls['email'].errors?.required)
          this.mensagem_erro = 'Preencha seu email\n';
        
        console.warn(this.mensagem_erro);
        console.warn(this.falha_preenchimento);
      }
    }
    
  }

}
