import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Disciplina } from './disciplinas';
import { Shipping } from './shippingInterface';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  items: Disciplina[] = [];
  shipping: Shipping;
  constructor(private http: HttpClient) { 
    this.shipping = {type:"Not selected", price:0};
  }
  
/* . . . */

  getShippingPrices() {
    return this.http.get<{type: string, price: number}[]>('/assets/shipping.json');
  }

  addToCart(disciplina: Disciplina) {
    this.items.push(disciplina);
  }

  getItems() {
    return this.items;
  }

  clearCart() {
    this.items = [];
    return this.items;
  }

  addShipping(option: Shipping)
  {
    this.shipping = option;
  }

}