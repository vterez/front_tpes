import { Component, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { disciplinas } from '../disciplinas';
import { UserService } from '../user.service';

@Component({
  selector: 'app-disciplina-list',
  templateUrl: './disciplina-list.component.html',
  styleUrls: ['./disciplina-list.component.css']
})
export class DisciplinaListComponent implements AfterViewInit{

  disciplinas = disciplinas;

  constructor(private user: UserService,
    private router: Router){};

  ngAfterViewInit()
  {
    if (!this.user.logado)
      this.router.navigate(['/']);
  }
}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/