import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Disciplina, Avaliacao, disciplinas } from '../disciplinas';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-disciplina-details',
  templateUrl: './disciplina-details.component.html',
  styleUrls: ['./disciplina-details.component.css']
})
export class DisciplinaDetailsComponent implements OnInit {

  disciplina: Disciplina | undefined;

  constructor(private route: ActivatedRoute,
    private cartService: CartService
    ) { };

    addToCart(disciplina: Disciplina) {
      this.cartService.addToCart(disciplina);
      window.alert('Your disciplina has been added to the cart!');
      
  }

  ngOnInit() {
    const routeParams = this.route.snapshot.paramMap;
    const disciplinaIdFromRoute = Number(routeParams.get('disciplinaId'));

    // Find the disciplina that correspond with the id provided in route.
    this.disciplina = disciplinas.find(disciplina => disciplina.id === disciplinaIdFromRoute);
  }

}